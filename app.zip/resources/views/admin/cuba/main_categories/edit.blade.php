@extends('layouts.admin.cuba')

@section('title', 'Categories | Edit')

@section('breadcrumb-items')
    <li class="breadcrumb-item">Categories</li>
    <li class="breadcrumb-item">Edit</li>
@stop


@section('content')
    <!-- Default box -->
    <div class="card card-solid">
        <div class="card-body parent-category-edit">
            <div class="row">
            <div class="edit-category-form">
                @include('admin.cuba.partials._errors')
                <form class="col-md-7 m-auto"  action="{{ route('admin.main_categories.update', $main_category -> id) }}" method="post" enctype="multipart/form-data">

                    {{ csrf_field() }}
                    {{ method_field('put') }}

                    <div class="row">
                        <div class="form-group col-sm-12 col-md-6 text-md">
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" @if($main_category -> is_active == 1 )checked @endif>
                                <label class="custom-control-label" for="is_active">Is Active</label>
                            </div>
                            @error('is_active')
                            <span class="text-danger mx-1">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="form-group col-sm-12 col-md-6 text-md">
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="show_in_navbar" name="show_in_navbar" @if($main_category -> show_in_navbar == 1 )checked @endif >
                                <label class="custom-control-label" for="show_in_navbar">Show in Navbar</label>
                            </div>
                            @error('show_in_navbar')
                            <span class="text-danger mx-1">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="form-group col-sm-12 col-md-6  text-md">
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="show_in_sidebar" name="show_in_sidebar" @if($main_category -> show_in_sidebar == 1 )checked @endif >
                                <label class="custom-control-label" for="show_in_sidebar">Show in Sidebar</label>
                            </div>
                            @error('show_in_sidebar')
                            <span class="text-danger mx-1">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="form-group col-sm-12 col-md-6 text-md">
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="show_in_footer" name="show_in_footer" @if($main_category -> show_in_footer == 1 )checked @endif>
                                <label class="custom-control-label" for="show_in_footer">Show in Footer</label>
                            </div>
                            @error('show_in_footer')
                            <span class="text-danger mx-1">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="col-sm-12 row">
                            <div class="form-group col-md-6">
                                <label class="  my-2" for="name"></label>
                                @error('name')
                                <span class="text-danger mx-5">{{ $message }}</span>
                                @enderror
                                <input class="form-control input-thick  text-center " type="text" name="name"
                                     placeholder="Category Name"  value="{{ $main_category -> name }}">
                            </div>

                            <div class="form-group col-md-6">
                                <label class="  my-2" for="slug"></label>
                                @error('slug')
                                <span class="text-danger mx-5">{{ $message }}</span>
                                @enderror
                                <input class="form-control input-thick  text-center " type="text" name="slug"
                                      placeholder="Slug" value="{{ $main_category -> slug }}">
                            </div>


                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                    <label class="  my-2" for="parent_id">Parent Category</label>
                                    @error('parent_id')
                                    <span class="text-danger mx-5">{{ $message }}</span>
                                    @enderror
                                    <select name="parent_id" class="form-control select-css ">
                                        <option value="0">Is Parent</option>
                                        @foreach($all_categories as $item)
                                        <option value="{{ $item -> id  }}" @if($main_category -> parent_id == $item -> id )selected @endif >{{ $item -> name  }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>


                            <div class="form-group col-sm-12 col-md-6">
                                <label class="  my-2" label for="image">Image</label>
                                @error('image')
                                <span class="text-danger mx-1">{{ $message }}</span>
                                @enderror
                                <input type="file" name="image" class="form-control input-sm image mb-4">

                               <img src="{{ $main_category -> image_path }}"
                                     class="img-thumbnail image-preview mt-1 image-preview img-fluid d-block m-auto" alt="{{ $main_category -> slug }}">
                            </div> {{-- end of form group image --}}

                        </div>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-received"><i class="fa fa-edit"></i>
                            Update Category</button>
                    </div>

                </form><!-- end of form -->
            </div>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
@stop
