<footer class="footer">
    <div class="container-fluid">
       
            <div class="col-12 footer-copyright text-center">
                <p class="mb-0">Copyright {{ date('Y') }} © {{ $site_settings -> title }} By <a href="https://spctec.com/" target="_blank">S.P.C TECH.</a>  </p>
          
        </div>
    </div>
</footer>
