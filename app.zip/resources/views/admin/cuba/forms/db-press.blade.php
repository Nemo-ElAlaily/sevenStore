<body>
  <section class="admin-database">
    <div class="container contact-form">
      <div class="contact-image">
        <img src="images/wordpress.png" alt="DB_Name" />

        <h3 class="headTitelPress">WordPress DataBase</h3>
      </div>
      <form method="post">
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label class="titel-db" for="">DB.Name</label>
              <input type="text" name="" class="form-control" placeholder="DB Name *" value="" />
            </div>
            <div class="form-group">
              <label class="titel-db" for="">DB.Url</label>
              <input type="url" name="" class="form-control" placeholder="DB Url *" value="" />
            </div>
            <div class="form-group">
              <label class="titel-db" for="">DB.Host</label>
              <input type="text" name="" class="form-control" placeholder="DB Host *" value="" />
            </div>
            <div class="form-group">
              <label class="titel-db" for="">User Name</label>
              <input type="text" name="" class="form-control" placeholder="Your Name *" value="" />
            </div>

            <div class="form-group">
              <label class="titel-db" for="">Password</label>
              <input type="password" name="" class="form-control" placeholder="Your Password *" value="" />
            </div>

            <div class="form-group">
              <input type="submit" name="" class="btnContactpress" value="Next" />
            </div>
          </div>
        </div>
      </form>
    </div>
  </section>
