<ul class="nav navbar-nav departments-menu animate-dropdown">
</ul>
