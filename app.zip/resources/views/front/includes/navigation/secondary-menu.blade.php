<nav>
    <ul id="menu-secondary-nav" class="secondary-nav">
        <li class="highlight menu-item"><a href="#">Super Deals</a></li>
        <li class="menu-item"><a href="#">Featured Brands</a></li>
        <li class="menu-item"><a href="#">Trending Styles</a></li>
        <li class="menu-item"><a href="#">Gift Cards</a></li>
        <li class="pull-right menu-item"><a href="#">Free Shipping on Orders $50+</a></li>
    </ul>
</nav>
