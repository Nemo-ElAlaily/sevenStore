<header id="masthead" class="site-header header-v3">
    <div class="container">
        <div class="row">

            @include('front.includes.header.header-logo')

            @include('front.includes.header.navbar-search')

            @include('front.includes.header.navbar-right')

        </div><!-- /.row -->
    </div>
</header><!-- #masthead -->
<nav class="navbar navbar-primary navbar-full">
    <div class="container">

        @include('front.includes.navigation.primary-nav')

    </div>
</nav>
