
<ul class="navbar-mini-cart navbar-nav animate-dropdown nav pull-right flip">
    @livewire('cart-count-component')
</ul>

<ul class="navbar-wishlist nav navbar-nav pull-right flip">
    @livewire('wishlist-count-component')
</ul>

<ul class="navbar-compare nav navbar-nav pull-right flip">
    @livewire('compare-count-component')
</ul>

