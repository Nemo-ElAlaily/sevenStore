<?php

return [
    'en' => [
        'name' => 'الانجليزية',
        'description' => 'الوصف',
    ],

    'ar' => [
        'name' => 'العربية',
        'description' => 'الوصف',
    ],
];
