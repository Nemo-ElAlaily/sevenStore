<?php

return [
    'en' => [
        'name' => 'English',
        'description' => 'Description',
    ],

    'ar' => [
        'name' => 'Arabic',
        'description' => 'Description',
    ],
];
