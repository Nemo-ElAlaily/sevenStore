<!-- ============================================================= Header Logo ============================================================= -->
<div class="header-logo">
    <a href="<?php echo e(route('front.index')); ?>" class="header-logo-link">
        <img class="logo-header" src="<?php echo e($site_settings -> logo_path); ?>" alt="<?php echo e($site_settings -> title); ?>"/>
    </a>

    <div class="toggleSide" id="">
        <i class="fa fa-align-justify" id="btnToggle"></i>
    </div>

</div>
<!-- ============================================================= Header Logo : End============================================================= -->
<div class="btnUp">
    <i class="fa fa-arrow-up"></i>
</div>

<?php echo $__env->make('front/includes/header/header-left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/front/includes/header/header-logo.blade.php ENDPATH**/ ?>