<?php if(session() -> has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session() -> get('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/front/partials/_session.blade.php ENDPATH**/ ?>