<?php if(session() -> has('error')): ?>
    <div class="alert alert-warning" role="alert">
        <?php echo e(session() -> get('error')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/front/partials/_errors.blade.php ENDPATH**/ ?>