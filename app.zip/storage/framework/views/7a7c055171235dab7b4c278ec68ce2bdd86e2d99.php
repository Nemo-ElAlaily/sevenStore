<li class="nav-item">
    <a href="<?php echo e(route('front.product.compare')); ?>" class="nav-link">
        <i class="ec ec-compare"></i>
        <?php if(Cart::instance('compare') -> count() > 0 ): ?>
            <span class="cart-items-count count"><?php echo e(Cart::instance('compare')-> count()); ?></span>
        <?php endif; ?>
    </a>
</li>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/livewire/compare-count-component.blade.php ENDPATH**/ ?>