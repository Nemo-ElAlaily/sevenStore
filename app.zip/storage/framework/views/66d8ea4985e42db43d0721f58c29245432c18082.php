<div class="top-bar">
    <div class="container">
        <nav>
            <ul id="menu-top-bar-left" class="nav nav-inline pull-left animate-dropdown flip">
                <li class="menu-item animate-dropdown"><a title="Welcome to Worldwide Electronics Store" href="#">Welcome to <?php echo e($site_settings -> welcome_phrase); ?></a></li>
            </ul>
        </nav>

        <nav>
            <ul id="menu-top-bar-right" class="nav nav-inline pull-right animate-dropdown flip">
                <li class="menu-item animate-dropdown">
                    <a title="Track Your Order" href="<?php echo e(route('front.orders')); ?>">
                        <i class="ec ec-transport"></i>Track Your Order
                    </a>
                </li>

                <li class="menu-item menu-item-has-children animate-dropdown dropdown">
                    <a title="Language" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">
                        <?php echo app('translator')->get('site.' . LaravelLocalization::getCurrentLocale() . '.name'); ?>
                    </a>
                    <ul role="menu" class="dropdown-menu">
                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="dropdown-item">
                                <a class="dropdown-item" title="<?php echo e($properties['native']); ?>" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>"><?php echo e($properties['native']); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>

                <li class="menu-item animate-dropdown"><a title="Shop" href="<?php echo e(route('front.shop')); ?>"><i class="ec ec-shopping-bag"></i>Shop</a></li>

                <?php if(auth()->guard()->guest()): ?>
                    <li class="menu-item animate-dropdown"><a title="Login" href="<?php echo e(route('login')); ?>"><i class="ec ec-user mr-1"></i> Register <span class="text-gray-50">or</span> Sign in</a></li>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <li class="menu-item menu-item-has-children animate-dropdown dropdown"><a title="My Account" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true"><i class="ec ec-user"></i><?php echo e(Auth::user() -> full_name); ?></a>
                        <ul role="menu" class="dropdown-menu">
                            <li class="dropdown-item"><a class="dropdown-item" title="My Profile" href="#">My Profile</a></li>
                            <?php if(Auth::user() -> hasRole('super_admin|admin|shop_manager|vendor|moderator')): ?>
                                <li class="dropdown-item"><a class="dropdown-item" title="My Profile" href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
                            <?php endif; ?>
                            <li class="dropdown-item ">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</div><!-- /.top-bar -->




<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/front/includes/header/top_bar.blade.php ENDPATH**/ ?>