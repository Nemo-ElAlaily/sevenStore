<?php if(session() -> has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session() -> get('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/front/partials/_session.blade.php ENDPATH**/ ?>