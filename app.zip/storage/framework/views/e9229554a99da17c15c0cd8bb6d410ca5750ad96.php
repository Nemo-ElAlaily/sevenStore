
<div class="home-v1-banner-block animate-in-view fadeIn animated" data-animation="fadeIn">

    <div class="home-v1-fullbanner-ad fullbanner-ad" style="margin-bottom: 70px">
        <a href="#">
            <img src="<?php echo e(asset('front')); ?>/images/blank.gif" data-echo="<?php echo e(asset('front')); ?>/images/banner/home-v1-banner.png" class="img-responsive" alt="">

        </a>
    </div>
</div><!-- /.home-v1-banner-block -->


<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/front/includes/homepage/home-banner.blade.php ENDPATH**/ ?>