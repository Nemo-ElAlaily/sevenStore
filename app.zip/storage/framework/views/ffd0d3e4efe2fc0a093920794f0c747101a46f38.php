<?php if(Session::has('success')): ?>

    <div class="row mt-3">
        <button type="text" class="text-sm  col-md-6 col-md-offset-3  btn successDelivered"
                id="type-error"><?php echo e(Session::get('success')); ?>

        </button>
    </div>

<?php endif; ?>
<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/admin/cuba/partials/_session.blade.php ENDPATH**/ ?>