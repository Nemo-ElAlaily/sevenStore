

<?php $__env->startSection('title', 'Blogs'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h5>Blogs <span class="small text-muted"><?php echo e($blogs ->total()); ?></span></h5>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Blogs</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">

        <div class="box-header with-border">

            <form action="<?php echo e(route('admin.blogs.index')); ?>" method="get">

                <div class="row mx-5">

                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Search Here..." value="<?php echo e(request()->search); ?>">
                    </div>

                    <div class="col-md-4 p-0">
                        <button type="submit" class="btn btnSearch"><i class="fa fa-search"></i> Search</button>
                        <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btnAdd"><i class="fa fa-plus"></i> Create Blog</a>
                    </div>

                </div>
            </form><!-- end of form -->

        </div><!-- end of box header -->

        <?php echo $__env->make('admin.cuba.partials._session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.cuba.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="box-body bg-white mx-5 mt-3">

 <!-- Start Blog -->
          
          <?php if($blogs->count() > 0): ?>
          <section class="blog section" id="blog">
            <div class="container">
             
          <div class="row">  
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-md-6 col-lg-4">
                    <div class="blog-item padd-15">
                        <div class="blog-item-inner shadow-dark">
                          <div class="blog-img">
                            <img src="<?php echo e($blog -> image_path); ?>" alt="Blog">
                            <div class="blog-date">
                                <?php echo e($index + 1); ?>

                            </div>
                          </div>
                          <div class="blog-info">
                            <h4 class="blog-title"><?php echo e($blog -> user -> full_name); ?></h4>
                            <p class="blog-description"><?php echo e($blog -> title); ?></p>
                            <p class="blog-tags">Blog Status : <a href="#"> <?php echo e($blog -> getActive()); ?></a></p>

                            <div class="blog-btns-actions">
                                <a href="<?php echo e(route('admin.blogs.show', $blog->id)); ?>" class="btn btnShow  btn-sm"><i class="fa fa-eye fa-lg text-lg"></i></a>
                                <a href="<?php echo e(route('admin.blogs.edit', $blog->id)); ?>" class="btn btnEdit btn-sm"><i class="fa fa-edit fa-lg text-lg"></i></a>
                                <form action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>" method="post" style="display: inline-block">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                    <button type="button" class="btn btnDelete show_confirm btn-sm"><i class="fa fa-trash fa-lg text-lg"></i></button>
                                </form><!-- end of form -->  
                            </div>
                        </div>
                        </div>
                      </div>

                                
                   
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
                <?php else: ?>
                    <h2 class="mt-5 text-center pt-2">No Data Found</h2>
                <?php endif; ?>

            </table><!-- end of table -->

        </div><!-- end of box body -->

        <div class="container">
            <?php echo e($blogs->appends(request()->query())->links()); ?>

        </div>
    </div><!-- end of box -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.cuba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/admin/cuba/blogs/index.blade.php ENDPATH**/ ?>