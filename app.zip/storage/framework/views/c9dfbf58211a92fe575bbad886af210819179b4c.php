<header id="masthead" class="site-header header-v3">
    <div class="container">
        <div class="row">

            <?php echo $__env->make('front.includes.header.header-logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('front.includes.header.navbar-search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('front.includes.header.navbar-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div><!-- /.row -->
    </div>
</header><!-- #masthead -->
<nav class="navbar navbar-primary navbar-full">
    <div class="container">

        <?php echo $__env->make('front.includes.navigation.primary-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
</nav>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/front/includes/header/header.blade.php ENDPATH**/ ?>