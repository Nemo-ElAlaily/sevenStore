
<ul class="navbar-mini-cart navbar-nav animate-dropdown nav pull-right flip">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-count-component')->html();
} elseif ($_instance->childHasBeenRendered('ULuHuqn')) {
    $componentId = $_instance->getRenderedChildComponentId('ULuHuqn');
    $componentTag = $_instance->getRenderedChildComponentTagName('ULuHuqn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ULuHuqn');
} else {
    $response = \Livewire\Livewire::mount('cart-count-component');
    $html = $response->html();
    $_instance->logRenderedChild('ULuHuqn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</ul>

<ul class="navbar-wishlist nav navbar-nav pull-right flip">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wishlist-count-component')->html();
} elseif ($_instance->childHasBeenRendered('oVErx7m')) {
    $componentId = $_instance->getRenderedChildComponentId('oVErx7m');
    $componentTag = $_instance->getRenderedChildComponentTagName('oVErx7m');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oVErx7m');
} else {
    $response = \Livewire\Livewire::mount('wishlist-count-component');
    $html = $response->html();
    $_instance->logRenderedChild('oVErx7m', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</ul>

<ul class="navbar-compare nav navbar-nav pull-right flip">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('compare-count-component')->html();
} elseif ($_instance->childHasBeenRendered('CDk73xz')) {
    $componentId = $_instance->getRenderedChildComponentId('CDk73xz');
    $componentTag = $_instance->getRenderedChildComponentTagName('CDk73xz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CDk73xz');
} else {
    $response = \Livewire\Livewire::mount('compare-count-component');
    $html = $response->html();
    $_instance->logRenderedChild('CDk73xz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</ul>

<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/front/includes/header/navbar-right.blade.php ENDPATH**/ ?>