<li class="nav-item dropdown">
    <a href="<?php echo e(route('front.product.cart')); ?>" class="nav-link" data-toggle="dropdown">
        <i class="ec ec-shopping-bag"></i>
        <span class="cart-items-count count" style="color: #fff"><?php echo e(Cart::instance('cart')->count()); ?></span>
        <span class="cart-items-total-price total-price"><span class="amount">&pound; <?php echo e(Cart::instance('cart')->subtotal()); ?></span></span>
    </a>
    <ul class="dropdown-menu dropdown-menu-mini-cart">
        <li>
            <div class="widget_shopping_cart_content">

                <ul class="cart_list product_list_widget ">

                    <?php if(Cart::instance('cart')->count() > 0): ?>
                        <?php $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mini_cart_item">
                                <a title="Remove this item" class="remove" href="#">×</a>
                                <a href="#">
                                    <img class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" src="<?php echo e($item -> model -> image_path); ?> " alt="<?php echo e($item -> model -> slug); ?>"><?php echo e($item -> model -> name); ?>&nbsp;
                                </a>

                                <span class="quantity"><?php echo e($item -> qty); ?> × <span class="amount">&pound; <?php echo e($item -> model -> sale_price); ?></span></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                </ul><!-- end product list -->


                <p class="total"><strong>Subtotal:</strong> <span class="amount">£969.98</span></p>


                <p class="buttons">
                    <a class="button wc-forward" href="<?php echo e(route('front.product.cart')); ?>">View Cart</a>
                    <a class="button checkout wc-forward" href="<?php echo e(route('front.checkout')); ?>">Checkout</a>
                </p>


            </div>
        </li>
    </ul>
</li>
<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/livewire/cart-count-component.blade.php ENDPATH**/ ?>