<?php $__env->startSection('title', 'Site Settings'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h5>General Settings</h5>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Settings</li>
    <li class="breadcrumb-item">General</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.cuba.partials._session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.cuba.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Default box -->
    <div class="card card-solid">
        <div class="card-body">
            <div class="row">
                <form class="col-12" action="<?php echo e(route('admin.settings.site.show', $site_settings->id)); ?>" method="post"
                      enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('put')); ?>

                    <ul class="nav nav-pills mb-3" id="lang-tab" role="tablist">
                        <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e($index == 0 ? 'active' : ''); ?>" id="'pills-<?php echo e($locale); ?>-tab'" data-toggle="pill" href="#<?php echo e($locale); ?>" role="tab" aria-controls="<?php echo e($locale); ?>" aria-selected="true"><?php echo app('translator')->get('site.' . $locale . '.name'); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content" id="lang-tabContent">
                      <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="tab-pane fade show <?php echo e($index == 0 ? 'active' : ''); ?>" id="<?php echo e($locale); ?>" role="tabpanel" aria-labelledby="pills-<?php echo e($locale); ?>-tab">
                              <div class="col-sm-12 col-lg-6">
                                  <div class="form-group">
                                      <label class="labelSetting" for="<?php echo e($locale); ?>">Title in <?php echo app('translator')->get('site.' . $locale .
                                        '.name'); ?></label>
                                      <?php $__errorArgs = [$locale . '.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <br />
                                      <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <input class="form-control   input-thick bg-dark text-center" type="text" name="<?php echo e($locale); ?>[title]"
                                             value="<?php echo e($site_settings->translate($locale)->title); ?>">
                                  </div>
                                  <div class="form-group">
                                      <label class="labelSetting" for="<?php echo e($locale); ?>">Welcome Phrase in <?php echo app('translator')->get('site.' . $locale .
                                        '.name'); ?></label>
                                      <?php $__errorArgs = [$locale . '.welcome_phrase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <br />
                                      <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <input class="form-control   input-thick bg-dark text-center" type="text" name="<?php echo e($locale); ?>[welcome_phrase]"
                                             value="<?php echo e($site_settings->translate($locale)->welcome_phrase); ?>">
                                  </div>
                                  <div class="form-group">
                                      <label class="labelSetting" for="<?php echo e($locale); ?>">Title in <?php echo app('translator')->get('site.' . $locale .
                                        '.name'); ?></label>
                                      <?php $__errorArgs = [$locale . '.address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <br />
                                      <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <input class="form-control   input-thick bg-dark text-center" type="text" name="<?php echo e($locale); ?>[address]"
                                             value="<?php echo e($site_settings->translate($locale)->address); ?>">
                                  </div>
                                  <div class="form-group">
                                      <label class="labelSetting" for="<?php echo e($locale); ?>">Title in <?php echo app('translator')->get('site.' . $locale .
                                        '.name'); ?></label>
                                      <?php $__errorArgs = [$locale . '.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <br />
                                      <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <input class="form-control   input-thick bg-dark text-center" type="text" name="<?php echo e($locale); ?>[city]"
                                             value="<?php echo e($site_settings->translate($locale)->city); ?>">
                                  </div>
                                  <div class="form-group">
                                      <label class="labelSetting" for="<?php echo e($locale); ?>">Title in <?php echo app('translator')->get('site.' . $locale .
                                        '.name'); ?></label>
                                      <?php $__errorArgs = [$locale . '.country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <br />
                                      <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <input class="form-control   input-thick bg-dark text-center" type="text" name="<?php echo e($locale); ?>[country]"
                                             value="<?php echo e($site_settings->translate($locale)->country); ?>">
                                  </div>

                                  <div class="form-group">
                                      <label class="labelSetting" for="<?php echo e($locale); ?>[meta_title]">Meta Title in <?php echo app('translator')->get('site.' .
                                        $locale . '.meta_title'); ?></label>
                                      <?php $__errorArgs = [$locale . '.meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <br />
                                      <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <input class="form-control   input-thick bg-dark text-center" type="text"
                                             name="<?php echo e($locale); ?>[meta_title]"
                                             value="<?php echo e($site_settings->translate($locale)->meta_title); ?>">
                                  </div>

                                  <div class="form-group">
                                      <label class="labelSetting" for="<?php echo e($locale); ?>[meta_description]">Meta Description in <?php echo app('translator')->get('site.' .
                                        $locale .
                                        '.meta_description'); ?></label>
                                      <?php $__errorArgs = [$locale . '.meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <br />
                                      <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <input class="form-control   input-thick bg-dark text-center" type="text"
                                             name="<?php echo e($locale); ?>[meta_description]"
                                             value="<?php echo e($site_settings->translate($locale)->meta_description); ?>">
                                  </div>

                                  <div class="form-group">
                                      <label class="labelSetting" for="<?php echo e($locale); ?>[meta_keyword]">Meta Keyword in <?php echo app('translator')->get('site.' .
                                        $locale . '.meta_keyword'); ?></label>
                                      <?php $__errorArgs = [$locale . '.meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <br />
                                      <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <input class="form-control   input-thick bg-dark text-center" type="text"
                                             name="<?php echo e($locale); ?>[meta_keyword]"
                                             value="<?php echo e($site_settings->translate($locale)->meta_keyword); ?>">
                                  </div>

                              </div>
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>


                  <div class="form-group">
                    <label class="labelSetting">Google Analytics</label>
                    <?php $__errorArgs = [$locale . '.meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br />
                    
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <textarea class="form-control   input-thick bg-dark text-center"
                           name="google_analytics"></textarea>
                </div>


                    <div class="row">

                        <div class="form-group col-sm-12 col-lg-6">
                            <label>Logo</label>
                            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="file" name="logo" class="form-control input-sm image" accept="jpg, png, jpeg, svg">

                            <img src="<?php echo e($site_settings -> logo_path); ?>" width="100px"
                                 class="img-thumbnail image-preview mt-1" alt="">
                        </div> 

                        <div class="form-group col-sm-6 col-lg-6">
                            <label>Favicon</label>
                            <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="file" name="favicon" class="form-control input-sm favicon" accept="jpg, png, jpeg, svg">

                            <img src="<?php echo e($site_settings -> favicon_path); ?>" width="100px"
                                 class="img-thumbnail favicon-preview mt-1" alt="">
                        </div> 

                    </div> 
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-edit"></i>
                            Update Site Settings</button>
                    </div>

                </form><!-- end of form -->

            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.cuba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/admin/cuba/site_settings/general.blade.php ENDPATH**/ ?>