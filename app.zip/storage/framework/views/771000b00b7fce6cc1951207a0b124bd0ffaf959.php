<div class="clearfix">
    <button class="navbar-toggler hidden-sm-up pull-right flip" type="button" data-toggle="collapse" data-target="#header-v3">
        &#9776;
    </button>
</div>

<div class="collapse navbar-toggleable-xs" id="header-v3">
    <ul class="nav navbar-nav">

        <?php $__currentLoopData = $main_categories -> where('parent_id', 0) -> slice(1 , 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="menu-item">
                <a title="Gadgets" href="<?php echo e(route('front.product.category', $main_category -> slug)); ?>"><?php echo e($main_category -> name); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><!-- /.collpase -->
<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/front/includes/navigation/primary-nav.blade.php ENDPATH**/ ?>