

<?php $__env->startSection('title', 'Categories | Edit'); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Categories</li>
    <li class="breadcrumb-item">Edit</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- Default box -->
    <div class="card card-solid">
        <div class="card-body parent-category-edit">
            <div class="row">
            <div class="edit-category-form">
                <?php echo $__env->make('admin.cuba.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form class="col-md-7 m-auto"  action="<?php echo e(route('admin.main_categories.update', $main_category -> id)); ?>" method="post" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('put')); ?>


                    <div class="row">
                        <div class="form-group col-sm-12 col-md-6 text-md">
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" <?php if($main_category -> is_active == 1 ): ?>checked <?php endif; ?>>
                                <label class="custom-control-label" for="is_active">Is Active</label>
                            </div>
                            <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-sm-12 col-md-6 text-md">
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="show_in_navbar" name="show_in_navbar" <?php if($main_category -> show_in_navbar == 1 ): ?>checked <?php endif; ?> >
                                <label class="custom-control-label" for="show_in_navbar">Show in Navbar</label>
                            </div>
                            <?php $__errorArgs = ['show_in_navbar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-sm-12 col-md-6  text-md">
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="show_in_sidebar" name="show_in_sidebar" <?php if($main_category -> show_in_sidebar == 1 ): ?>checked <?php endif; ?> >
                                <label class="custom-control-label" for="show_in_sidebar">Show in Sidebar</label>
                            </div>
                            <?php $__errorArgs = ['show_in_sidebar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-sm-12 col-md-6 text-md">
                            <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="show_in_footer" name="show_in_footer" <?php if($main_category -> show_in_footer == 1 ): ?>checked <?php endif; ?>>
                                <label class="custom-control-label" for="show_in_footer">Show in Footer</label>
                            </div>
                            <?php $__errorArgs = ['show_in_footer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-12 row">
                            <div class="form-group col-md-6">
                                <label class="  my-2" for="name"></label>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input class="form-control input-thick  text-center " type="text" name="name"
                                     placeholder="Category Name"  value="<?php echo e($main_category -> name); ?>">
                            </div>

                            <div class="form-group col-md-6">
                                <label class="  my-2" for="slug"></label>
                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input class="form-control input-thick  text-center " type="text" name="slug"
                                      placeholder="Slug" value="<?php echo e($main_category -> slug); ?>">
                            </div>


                            <div class="col-sm-12 col-md-6">
                                <div class="form-group">
                                    <label class="  my-2" for="parent_id">Parent Category</label>
                                    <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <select name="parent_id" class="form-control select-css ">
                                        <option value="0">Is Parent</option>
                                        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item -> id); ?>" <?php if($main_category -> parent_id == $item -> id ): ?>selected <?php endif; ?> ><?php echo e($item -> name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>


                            <div class="form-group col-sm-12 col-md-6">
                                <label class="  my-2" label for="image">Image</label>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger mx-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="file" name="image" class="form-control input-sm image mb-4">

                               <img src="<?php echo e($main_category -> image_path); ?>"
                                     class="img-thumbnail image-preview mt-1 image-preview img-fluid d-block m-auto" alt="<?php echo e($main_category -> slug); ?>">
                            </div> 

                        </div>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-received"><i class="fa fa-edit"></i>
                            Update Category</button>
                    </div>

                </form><!-- end of form -->
            </div>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.cuba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/admin/cuba/main_categories/edit.blade.php ENDPATH**/ ?>