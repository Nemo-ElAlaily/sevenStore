<footer class="footer">
    <div class="container-fluid">
       
            <div class="col-12 footer-copyright text-center">
                <p class="mb-0">Copyright <?php echo e(date('Y')); ?> © <?php echo e($site_settings -> title); ?> By <a href="https://spctec.com/" target="_blank">S.P.C TECH.</a>  </p>
          
        </div>
    </div>
</footer>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/admin/cuba/includes/footer.blade.php ENDPATH**/ ?>