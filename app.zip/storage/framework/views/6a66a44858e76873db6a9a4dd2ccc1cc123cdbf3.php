<form class="navbar-search" method="get" action="<?php echo e(route('front.shop')); ?>">
    <label class="sr-only screen-reader-text" for="search">Search for:</label>
    <div class="input-group">
        <input type="text" id="search" class="form-control search-field" dir="ltr" value="<?php echo e(request() -> search); ?>" name="search" placeholder="Search for products" />
        <div class="input-group-addon search-categories">
            <select name='product_cat' id='product_cat' class='postform resizeselect' >
                <option value='0' selected='selected'>All Categories</option>
                <?php $__currentLoopData = $main_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option class="level-0" value="<?php echo e($main_category -> id); ?>"><?php echo e($main_category -> name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="input-group-btn">
            <input type="hidden" id="search-param" name="post_type" value="<?php echo e(request() -> search); ?>" />
            <button type="submit" class="btn btn-secondary"><i class="ec ec-search"></i></button>
        </div>
    </div>
</form>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/front/includes/header/navbar-search.blade.php ENDPATH**/ ?>