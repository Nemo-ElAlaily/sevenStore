
<ul class="navbar-mini-cart navbar-nav animate-dropdown nav pull-right flip">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-count-component')->html();
} elseif ($_instance->childHasBeenRendered('1RiBH4s')) {
    $componentId = $_instance->getRenderedChildComponentId('1RiBH4s');
    $componentTag = $_instance->getRenderedChildComponentTagName('1RiBH4s');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1RiBH4s');
} else {
    $response = \Livewire\Livewire::mount('cart-count-component');
    $html = $response->html();
    $_instance->logRenderedChild('1RiBH4s', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</ul>

<ul class="navbar-wishlist nav navbar-nav pull-right flip">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wishlist-count-component')->html();
} elseif ($_instance->childHasBeenRendered('v9D50aK')) {
    $componentId = $_instance->getRenderedChildComponentId('v9D50aK');
    $componentTag = $_instance->getRenderedChildComponentTagName('v9D50aK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('v9D50aK');
} else {
    $response = \Livewire\Livewire::mount('wishlist-count-component');
    $html = $response->html();
    $_instance->logRenderedChild('v9D50aK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</ul>

<ul class="navbar-compare nav navbar-nav pull-right flip">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('compare-count-component')->html();
} elseif ($_instance->childHasBeenRendered('2MOoCA8')) {
    $componentId = $_instance->getRenderedChildComponentId('2MOoCA8');
    $componentTag = $_instance->getRenderedChildComponentTagName('2MOoCA8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2MOoCA8');
} else {
    $response = \Livewire\Livewire::mount('compare-count-component');
    $html = $response->html();
    $_instance->logRenderedChild('2MOoCA8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</ul>

<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/front/includes/header/navbar-right.blade.php ENDPATH**/ ?>