<?php if(Session::has('error')): ?>

    <div class="row mt-3">
        <button type="text" class="text-sm col-md-6 col-md-offset-3  btn wrongDelivered"
                id="type-error"><?php echo e(Session::get('error')); ?>

        </button>
    </div>

<?php endif; ?>
<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/admin/cuba/partials/_errors.blade.php ENDPATH**/ ?>