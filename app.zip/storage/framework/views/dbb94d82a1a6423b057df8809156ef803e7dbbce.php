

<?php $__env->startSection('title', $page -> title); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Pages</li>
    <li class="breadcrumb-item">Edit</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Default box -->
    <div class="card card-solid">
        <div class="card-body page-create-parent">
            <div class="row">

                <form class="col-12 page-create-form p-5" action="<?php echo e(route('admin.pages.update' , $page -> id)); ?>" method="post" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('put')); ?>


                    <div class="row">
                        <div class="form-group col-sm-12 col-md-3 text-md">
                            <div class="checkbox checkbox-secondary">
                                <input type="checkbox" class="custom-control-input" id="is_active" name="is_active" <?php if($page -> is_active == 1 ): ?>checked <?php endif; ?>>
                                <label class="labelPage" for="is_active">Is Active</label>
                            </div>
                            <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-sm-12 col-md-3 text-md">
                            <div class="checkbox checkbox-warning">
                                <input type="checkbox" class="custom-control-input" id="show_in_navbar" name="show_in_navbar"  <?php if($page -> show_in_navbar == 1 ): ?>checked <?php endif; ?> >
                                <label class="labelPage" for="show_in_navbar">Show in Navbar</label>
                            </div>
                            <?php $__errorArgs = ['show_in_navbar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-sm-12 col-md-3 text-md">
                            <div class="checkbox checkbox-info">
                                <input type="checkbox" class="custom-control-input" id="show_in_sidebar" name="show_in_sidebar"  <?php if($page -> show_in_sidebar == 1 ): ?>checked <?php endif; ?> >
                                <label class="labelPage" for="show_in_sidebar">Show in Sidebar</label>
                            </div>
                            <?php $__errorArgs = ['show_in_sidebar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-sm-12 col-md-3 text-md">
                            <div class="checkbox checkbox-primary">
                                <input type="checkbox" class="custom-control-input" id="show_in_footer" name="show_in_footer" <?php if($page -> show_in_footer == 1 ): ?>checked <?php endif; ?>>
                                <label class="labelPage" for="show_in_footer">Show in Footer</label>
                            </div>
                            <?php $__errorArgs = ['show_in_footer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mx-1"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mt-5">

                                <div class="form-group col-md-6 mb-5">
                                    <label class="labelPage" for="<?php echo e($locale); ?>[title]">Page Title in <?php echo app('translator')->get('site.' . $locale . '.name'); ?></label>
                                    <?php $__errorArgs = [$locale . '.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br />
                                    <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input class="form-control input-thick" type="text" name="<?php echo e($locale); ?>[title]"
                                           value="<?php echo e($page->translate($locale)-> title); ?>">
                                </div>
                                <div class="form-group col-md-6 mb-5">
                                    <label class="labelPage" for="<?php echo e($locale); ?>[slug]">Page Slug in <?php echo app('translator')->get('site.' . $locale . '.name'); ?></label>
                                    <?php $__errorArgs = [$locale . '.slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br />
                                    <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input class="form-control input-thick" type="text" name="<?php echo e($locale); ?>[slug]"
                                           value="<?php echo e($page->translate($locale)-> slug); ?>">
                                </div>


                                <div class="form-group col-md-6 mb-5">
                                    <label class="labelPage" for="<?php echo e($locale); ?>[content]">Page Content in <?php echo app('translator')->get('site.' . $locale . '.name'); ?></label>
                                    <?php $__errorArgs = [$locale . '.content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br />
                                    <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <textarea class="form-control input-thick textareaBlog" type="text" name="<?php echo e($locale); ?>[content]"><?php echo e($page->translate($locale)-> content); ?></textarea>
                                </div>

                                <div class="form-group col-md-6 mb-5">
                                    <label class="labelPage" class="labelSetting" for="<?php echo e($locale); ?>[meta_title]">Meta Title in <?php echo app('translator')->get('site.' .
                                        $locale . '.meta_title'); ?></label>
                                    <?php $__errorArgs = [$locale . '.meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br />
                                    <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input class="form-control   input-thick  text-center" type="text"
                                           name="<?php echo e($locale); ?>[meta_title]"
                                           value="<?php echo e($page->meta_title); ?>">
                                </div>

                                <div class="form-group col-md-6 mb-5">
                                    <label class="labelPage" class="labelSetting" for="<?php echo e($locale); ?>[meta_description]">Meta Description in <?php echo app('translator')->get('site.' .
                                        $locale .
                                        '.meta_description'); ?></label>
                                    <?php $__errorArgs = [$locale . '.meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br />
                                    <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input class="form-control   input-thick  text-center" type="text"
                                           name="<?php echo e($locale); ?>[meta_description]"
                                           value="<?php echo e($page->meta_description); ?>">
                                </div>

                                <div class="form-group col-md-6 mb-5">
                                    <label class="labelPage" for="<?php echo e($locale); ?>[meta_keyword]">Meta Keyword in <?php echo app('translator')->get('site.' .
                                        $locale . '.meta_keyword'); ?></label>
                                    <?php $__errorArgs = [$locale . '.meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br />
                                    <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input class="form-control   input-thick  text-center" type="text"
                                           name="<?php echo e($locale); ?>[meta_keyword]"
                                           value="<?php echo e($page -> meta_keyword); ?>">
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-secondary"><i class="fa fa-edit"></i>
                            Update Page</button>
                    </div>

                </form><!-- end of form -->

            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.cuba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/admin/cuba/pages/edit.blade.php ENDPATH**/ ?>