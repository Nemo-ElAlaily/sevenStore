
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/font-awesome.css')); ?>">
<!-- ico-font-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/vendors/icofont.css')); ?>">
<!-- Themify icon-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/vendors/themify.css')); ?>">
<!-- Flag icon-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/vendors/flag-icon.css')); ?>">
<!-- Feather icon-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/vendors/feather-icon.css')); ?>">
<!-- Plugins css start-->
<?php echo $__env->yieldContent('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/vendors/scrollbar.css')); ?>">
<!-- Bootstrap css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/vendors/bootstrap.css')); ?>">
<!-- App css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/style.css')); ?>">
<link id="color" rel="stylesheet" href="<?php echo e(asset('admins/cuba/assets/css/color-1.css')); ?>" media="screen">
<!-- Responsive css-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/animate.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admins/cuba/assets/css/responsive.css')); ?>">
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/admin/cuba/includes/css.blade.php ENDPATH**/ ?>