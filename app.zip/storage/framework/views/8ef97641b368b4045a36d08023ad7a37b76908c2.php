

<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h5>Categories <span class="small text-muted"><?php echo e($main_categories ->total()); ?></span></h5>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Categories</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">

            <form action="<?php echo e(route('admin.main_categories.index')); ?>" method="get">

                <div class="row mx-5">

                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Search Here..." value="<?php echo e(request()->search); ?>">
                    </div>

                    <div class="col-md-4 p-0">
                        <button type="submit" class="btn btnSearch"><i class="fa fa-search"></i> Search</button>
                        <a href="<?php echo e(route('admin.main_categories.create')); ?>" class="btn btnAdd"><i class="fa fa-plus"></i> Add Category</a>
                    </div>

                </div>
            </form><!-- end of form -->

        </div><!-- end of box header -->

        <?php echo $__env->make('admin.cuba.partials._session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.cuba.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="box-body bg-white mx-5 mt-3">

           <div class="container">
               <div class="row">

               
                <?php if($main_categories->count() > 0): ?>
                
                    <?php $__currentLoopData = $main_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$main_catogory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                           
                            <div class=" card-shadow">
                                <div class="card-group card-category">
                                    <div class="card">
                                      <img class="card-img-top img-category" src="<?php echo e($main_catogory -> image_path); ?>" alt="Card image cap">
                                      <div class="card-body">
                                        <span class="badge name-category">Name:</span>
                                        <h5 class="card-title"><?php echo e($main_catogory -> name); ?></h5>
                                        <p class="card-text"><span class="badge products-category">Products</span> <span class="badge badge-secondary"># <?php echo e($index + 1); ?></span></p>
                                      </div>
                                      
                                      <div class="card-footer">
                                          
                                        <span class="actions badge">Actions</span>
                                        <div class="all-buttons-functions">
                                            <a href="<?php echo e(route('admin.main_categories.show', $main_catogory->id)); ?>" class="btn btnShow"><i class="fa fa-eye "></i></a>
                                            <a href="<?php echo e(route('admin.main_categories.edit', $main_catogory->id)); ?>" class="btn btnEdit"><i class="fa fa-edit"></i></a>
                                            <form action="<?php echo e(route('admin.main_categories.destroy', $main_catogory->id)); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('delete')); ?>

                                                <button type="button" class="btn btnDelete show_confirm btn-sm"><i class="fa fa-trash"></i></button>
                                            </form><!-- end of form -->
                                        </div>
                                      </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                <?php else: ?>
                    <h2 class="mt-5 text-center pt-2">No Data Found</h2>
                <?php endif; ?>

            </div>
        </div>

        </div><!-- end of box body -->

        <div class="container">
            <?php echo e($main_categories->appends(request()->query())->links()); ?>

        </div>
    </div><!-- end of box -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.cuba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/admin/cuba/main_categories/index.blade.php ENDPATH**/ ?>