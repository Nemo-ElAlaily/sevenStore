

<?php $__env->startSection('title', 'Site Settings'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h5>Social Settings</h5>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Settings</li>
    <li class="breadcrumb-item">Social</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box-body mx-5 mt-3">

        <?php echo $__env->make('admin.cuba.partials._session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.cuba.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form class="col-12"  action="<?php echo e(route('admin.settings.social.update')); ?>" method="POST" enctype="multipart/form-data">

            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('POST')); ?>


            <div class="row">
                <div class="col-sm-12 row">
                    <table class="text-center pt-2 table table-hover table-bordered">
                        <?php if($socials->count() > 0): ?>
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Link</th>
                                <th>Notes</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e(ucfirst($social -> key)); ?></td>
                                    <td>
                                        <div class="form-group">
                                            <input class="form-control input-thick" type="text" name="<?php echo e($social -> key); ?>"
                                                       value="<?php echo e($social -> value != null ? $social -> value : old( $social -> key )); ?>" placeholder="https://">
                                        </div>
                                    </td>

                                    <td>
                                        <?php $__errorArgs = [$social -> key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger mx-5"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="form-group">
                                <button type="submit" class="btn btnAdd"><i class="fa fa-edit"></i>
                                    Update Social Links</button>
                            </div>

                            </tbody>

                        <?php else: ?>
                            <h2 class="mt-5 text-center pt-2">No Data Found</h2>
                        <?php endif; ?>

                    </table><!-- end of table -->

                </div>
            </div>

        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.cuba', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/admin/cuba/site_settings/social.blade.php ENDPATH**/ ?>