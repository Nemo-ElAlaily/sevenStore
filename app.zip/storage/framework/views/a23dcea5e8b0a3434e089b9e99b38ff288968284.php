<?php
    $witems = Cart::instance('wishlist')->content()->pluck('id');
    $compareItems = Cart::instance('compare')->content()->pluck('id');
?>

<?php $__currentLoopData = $latest_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="product">
    <div class="product-outer" style="height: 331px;">
        <div class="product-inner">
            <span class="loop-product-categories">
                <a href="<?php echo e(route('front.product.category', $product -> mainCategory -> slug)); ?>" rel="tag"><?php echo e($product -> mainCategory -> name); ?></a></span>
            <a href="<?php echo e(route('front.product.details', $product -> slug )); ?>">
                <h3><?php echo e($product -> name); ?></h3>
                <div class="product-thumbnail">
                    <img style="height: 150px;margin: auto" src="<?php echo e($product -> image_path); ?>" class="img-responsive" alt="<?php echo e($product -> slug); ?>">
                </div>
            </a>

            <div class="price-add-to-cart">
            <span class="price">
                <span class="electro-price">
                    <ins>
                        <span class="amount"> </span>
                    </ins>
                    <span class="amount">&pound; <?php echo e($product -> sale_price); ?></span>
                </span>
            </span>
                <a rel="nofollow" wire:click.prevent="store( '<?php echo e($product -> id); ?>', '<?php echo e($product -> name); ?>', '<?php echo e($product -> sale_price); ?>' )" class="button add_to_cart_button">Add to cart</a>
            </div><!-- /.price-add-to-cart -->

            <div class="hover-area">
                <div class="action-buttons">

                    <?php if($witems -> contains($product -> id)): ?>
                        <a href="#" rel="nofollow" style="color: #ea1b25" wire:click.prevent="removeFromWishlist('<?php echo e($product -> id); ?>')">
                            <i class="fa fa-heart"></i>
                            Wishlist
                        </a>
                    <?php else: ?>
                        <a href="#" rel="nofollow" class="btn-add-to-wishlist" wire:click.prevent="addToWishlist('<?php echo e($product -> id); ?>', '<?php echo e($product -> name); ?>', '<?php echo e($product -> sale_price); ?>')">
                            <i class="fa fa-heart-o"></i>
                            Wishlist
                        </a>
                    <?php endif; ?>

                    <?php if($compareItems -> contains($product -> id)): ?>
                        <a class="add-to-compare-link" href="#" rel="nofollow" style="color: #ea1b25" wire:click.prevent="removeFromCompare('<?php echo e($product -> id); ?>')">
                            Compare
                        </a>
                    <?php else: ?>
                        <a class="add-to-compare-link" href="#" rel="nofollow" class="btn-add-to-wishlist" wire:click.prevent="addToCompare('<?php echo e($product -> id); ?>', '<?php echo e($product -> name); ?>', '<?php echo e($product -> sale_price); ?>')">
                            Compare
                        </a>
                    <?php endif; ?>

                </div>
            </div>
        </div><!-- /.product-inner -->
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/front/includes/components/product-carousel-item.blade.php ENDPATH**/ ?>