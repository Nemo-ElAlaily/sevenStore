<li class="nav-item">
    <a href="<?php echo e(route('front.product.wishlist')); ?>" class="nav-link">
        <i class="ec ec-favorites"></i>
        <?php if(Cart::instance('wishlist') -> count() > 0 ): ?>
            <span class="cart-items-count count"><?php echo e(Cart::instance('wishlist')-> count()); ?></span>
        <?php endif; ?>
    </a>
</li>
<?php /**PATH E:\Billy\SPC-PROJECTS\sevenStore\resources\views/livewire/wishlist-count-component.blade.php ENDPATH**/ ?>