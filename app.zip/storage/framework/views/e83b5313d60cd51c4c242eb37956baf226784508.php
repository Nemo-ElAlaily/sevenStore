<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="product">
    <div class="product-outer" style="height: 331px;">
        <div class="product-inner">
            <span class="loop-product-categories">
                <a href="<?php echo e(route('front.product.category', $category -> slug)); ?>" rel="tag"><?php echo e($category -> name); ?></a></span>
            <a href="<?php echo e(route('front.product.category', $category -> slug )); ?>">
                <h3><?php echo e($category -> name); ?></h3>
                <div class="product-thumbnail">
                    <img style="height: 150px;margin: auto" src="<?php echo e($category -> image_path); ?>" class="img-responsive" alt="<?php echo e($category -> slug); ?>">
                </div>
            </a>

        </div><!-- /.product-inner -->
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/front/includes/components/category-carousel-item.blade.php ENDPATH**/ ?>