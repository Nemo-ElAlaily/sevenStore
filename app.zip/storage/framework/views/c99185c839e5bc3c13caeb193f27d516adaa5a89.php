<!DOCTYPE html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
<head>

    <?php echo $site_settings -> google_analytics; ?>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e($site_settings -> title); ?></title>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>" media="all" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/font-awesome.min.css')); ?>" media="all" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/font-electro.css')); ?>" media="all" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/owl-carousel.css')); ?>" media="all" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/style-' . LaravelLocalization::getCurrentLocaleDirection() . '.css')); ?>" media="all" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/colors/yellow.css')); ?>" media="all" />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,700italic,800,800italic,600italic,400italic,300italic' rel='stylesheet' type='text/css'>

    <link rel="shortcut icon" href="<?php echo e($site_settings -> favicon_path); ?>">

    <?php echo \Livewire\Livewire::styles(); ?>


    <script type="text/javascript" src="<?php echo e(asset('front/js/jquery.min.js')); ?>"></script>

</head>

<?php if(Route::is('front.shop') || Route::is('front.product.details') || Route::is('front.product.category')): ?>
<body class="left-sidebar single-product">
<?php elseif(Route::is('front.blog')): ?>
    <body class="blog blog-list right-sidebar">
<?php elseif(Route::is('front.blog.details')): ?>
    <body class="single-post right-sidebar">
<?php else: ?>
<body class="page home page-template-default">
<?php endif; ?>
    <div id="page" class="hfeed site">

        <?php echo $__env->make('front.includes.header.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->make('front.includes.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(Route::is('front.*')): ?>
            <?php echo e($slot); ?>

        <?php else: ?>
            <?php echo $__env->yieldContent('content'); ?>
        <?php endif; ?>





        <?php echo $__env->make('front.includes.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div><!-- #page -->

    <script type="text/javascript" src="<?php echo e(asset('front/js/tether.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/bootstrap-hover-dropdown.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/owl.carousel.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/echo.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/wow.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/jquery.easing.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/jquery.waypoints.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/electro.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('front/js/custom-' . LaravelLocalization::getCurrentLocaleDirection() . '.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /home/future/public_html/test.futurecityapp.com/resources/views/layouts/front/app.blade.php ENDPATH**/ ?>