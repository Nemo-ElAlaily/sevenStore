<?php

namespace App\Models\Laratrust;

use Laratrust\Models\LaratrustRole;

class Role extends LaratrustRole
{
    public $guarded = [];
}
